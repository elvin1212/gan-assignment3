import torch
import torch.nn as nn
import torch.optim as optim
import torchvision
import torchvision.transforms as transforms
from torch.utils.data import DataLoader
from torchvision.datasets import MNIST
import matplotlib.pyplot as plt
import numpy as np

# 设置随机种子以确保可重复性
torch.manual_seed(42)

# 设置设备
device = torch.device('mps' if torch.backends.mps.is_available() else ('cuda' if torch.cuda.is_available() else 'cpu'))

# 生成器网络
class Generator(nn.Module):
    def __init__(self):
        super(Generator, self).__init__()
        self.fc = nn.Linear(100, 7 * 7 * 128)
        self.tconv1 = nn.ConvTranspose2d(128, 64, 4, 2, 1)
        self.bn1 = nn.BatchNorm2d(64)
        self.relu = nn.ReLU(True)
        self.tconv2 = nn.ConvTranspose2d(64, 1, 4, 2, 1)
        self.tanh = nn.Tanh()

    def forward(self, x):
        x = self.fc(x)
        x = x.view(-1, 128, 7, 7)
        x = self.relu(self.bn1(self.tconv1(x)))
        x = self.tanh(self.tconv2(x))
        return x

# 判别器网络
# class Discriminator(nn.Module):
#     def __init__(self):
#         super(Discriminator, self).__init__()
#         self.conv1 = nn.Conv2d(1, 64, 4, 2, 1)     
#         self.lrelu = nn.LeakyReLU(0.2, inplace=True)
#         self.conv2 = nn.Conv2d(64, 128, 4, 2, 1)  
#         self.bn2 = nn.BatchNorm2d(128)
#         self.flatten = nn.Flatten()
#         self.linear = nn.Linear(128 * 7 * 7, 1)     
#         self.sigmoid = nn.Sigmoid()

#     def forward(self, x):
#         x = self.lrelu(self.conv1(x))
#         x = self.lrelu(self.bn2(self.conv2(x)))   
#         x = self.flatten(x)
#         x = self.linear(x)
#         x = self.sigmoid(x)
#         return x
class Discriminator(nn.Module):
    def __init__(self):
        super(Discriminator, self).__init__()
        self.conv1 = nn.Conv2d(1, 64, 4, 2, 1)     
        self.lrelu = nn.LeakyReLU(0.2, inplace=True)
        self.dropout1 = nn.Dropout2d(0.3)  

        self.conv2 = nn.Conv2d(64, 128, 4, 2, 1)  
        self.bn2 = nn.BatchNorm2d(128)
        self.dropout2 = nn.Dropout2d(0.3)  

        self.flatten = nn.Flatten()
        self.linear = nn.Linear(128 * 7 * 7, 1)     
        self.sigmoid = nn.Sigmoid() 

    def forward(self, x):
        x = self.lrelu(self.conv1(x))
        x = self.dropout1(x)  
        
        x = self.lrelu(self.bn2(self.conv2(x)))   
        x = self.dropout2(x)  
        
        x = self.flatten(x)
        x = self.linear(x)
        x = self.sigmoid(x) 
        return x

# 超参数设置
latent_dim = 100  # 潜在空间维度，较大的维度有助于生成更多样的图像
batch_size = 64   # 批次大小，平衡训练效率和内存占用
num_epochs = 100  # 训练轮数
lr = 0.0002      # 学习率，GAN训练需要较小的学习率以保持稳定
beta1 = 0.5      # Adam优化器的beta1参数，较小的值有助于训练稳定

# 数据加载和预处理
transform = transforms.Compose([
    transforms.ToTensor(),
    transforms.Normalize((0.5,), (0.5,))
])

dataset = MNIST(root='./data', train=True, download=True, transform=transform)
dataloader = DataLoader(dataset, batch_size=batch_size, shuffle=True)

# 初始化网络
generator = Generator().to(device)
discriminator = Discriminator().to(device)

# 损失函数和优化器
criterion = nn.BCELoss()
g_optimizer = optim.Adam(generator.parameters(), lr=lr, betas=(beta1, 0.999))
d_optimizer = optim.Adam(discriminator.parameters(), lr=lr, betas=(beta1, 0.999))

# 训练函数
def train():
    for epoch in range(num_epochs):
        for i, (real_images, _) in enumerate(dataloader):
            batch_size = real_images.size(0)
            real_images = real_images.to(device)
            
            # 训练判别器
            d_optimizer.zero_grad()
            label_real = torch.ones(batch_size, 1).to(device)
            label_fake = torch.zeros(batch_size, 1).to(device)
            
            output_real = discriminator(real_images)
            d_loss_real = criterion(output_real, label_real)
            
            noise = torch.randn(batch_size, latent_dim).to(device)
            fake_images = generator(noise)
            output_fake = discriminator(fake_images.detach())
            d_loss_fake = criterion(output_fake, label_fake)
            
            d_loss = d_loss_real + d_loss_fake
            d_loss.backward()
            d_optimizer.step()
            
            # 训练生成器
            g_optimizer.zero_grad()
            output_fake = discriminator(fake_images)
            g_loss = criterion(output_fake, label_real)
            
            g_loss.backward()
            g_optimizer.step()
            
            if i % 1000 == 0:
                print(f'Epoch [{epoch}/{num_epochs}] Batch [{i}/{len(dataloader)}] '
                      f'd_loss: {d_loss.item():.4f} g_loss: {g_loss.item():.4f}')
        
        if (epoch + 1) % 10 == 0:
            save_fake_images(epoch + 1)

# 保存生成的图像
def save_fake_images(epoch):
    generator.eval()
    with torch.no_grad():
        noise = torch.randn(16, latent_dim).to(device)
        fake_images = generator(noise)
        fake_images = fake_images.cpu().numpy()
        
        plt.figure(figsize=(4, 4))
        for i in range(16):
            plt.subplot(4, 4, i + 1)
            plt.imshow(fake_images[i, 0], cmap='gray')
            plt.axis('off')
        
        plt.savefig(f'new_fake_images_epoch_{epoch}.png')
        plt.close()
    generator.train()

if __name__ == '__main__':
    train()