# model.py
import torch.nn as nn

def get_model(model_name):
    """
    根据模型名称返回相应的神经网络模型实例。
    
    Args:
        model_name (str): 模型名称，例如 'FCNN', 'CNN', 'EnhancedCNN', 'VAE', 'GAN'
        
    Returns:
        nn.Module: 对应的模型实例
    """
    # TODO: define and return the appropriate model_name- one of: FCNN, CNN, EnhancedCNN, VAE, GAN
    if model_name == "GAN":
        return GAN()
    else:
        # 如果是其他模型（如FCNN, CNN等），这里需要添加对应的逻辑
        # 由于原始文档未提供，此处仅作为占位符
        raise NotImplementedError(f"Model {model_name} is not implemented.")

class Generator(nn.Module):
    """生成器网络"""
    def __init__(self):
        super(Generator, self).__init__()
        self.fc = nn.Linear(100, 7 * 7 * 128)  # 输入噪声向量 -> 7x7x128
        
        # 转置卷积层
        self.tconv1 = nn.ConvTranspose2d(
            in_channels=128, 
            out_channels=64, 
            kernel_size=4, 
            stride=2, 
            padding=1
        )
        self.bn1 = nn.BatchNorm2d(64)
        self.relu = nn.ReLU(True)

        self.tconv2 = nn.ConvTranspose2d(
            in_channels=64, 
            out_channels=1, 
            kernel_size=4, 
            stride=2, 
            padding=1
        )
        self.tanh = nn.Tanh()

    def forward(self, x):
        x = self.fc(x)
        x = x.view(-1, 128, 7, 7)  # Reshape to (BATCH_SIZE, 128, 7, 7)
        x = self.relu(self.bn1(self.tconv1(x)))
        x = self.tanh(self.tconv2(x))
        return x


class Discriminator(nn.Module):
    """判别器网络"""
    def __init__(self):
        super(Discriminator, self).__init__()
        # 卷积层
        self.conv1 = nn.Conv2d(
            in_channels=1, 
            out_channels=64, 
            kernel_size=4, 
            stride=2, 
            padding=1
        )
        self.lrelu = nn.LeakyReLU(0.2, inplace=True)

        self.conv2 = nn.Conv2d(
            in_channels=64, 
            out_channels=128, 
            kernel_size=4, 
            stride=2, 
            padding=1
        )
        self.bn2 = nn.BatchNorm2d(128)

        # 输出层
        self.flatten = nn.Flatten()
        self.linear = nn.Linear(128 * 7 * 7, 1)  # 将 128x7x7 展平后映射到单个输出

    def forward(self, x):
        x = self.lrelu(self.conv1(x))
        x = self.lrelu(self.bn2(self.conv2(x)))
        x = self.flatten(x)
        x = self.linear(x)
        return x


class GAN(nn.Module):
    """完整的GAN模型，包含生成器和判别器"""
    def __init__(self):
        super(GAN, self).__init__()
        self.generator = Generator()
        self.discriminator = Discriminator()
    
    def forward(self, x, mode='discriminator'):
        """
        前向传播。
        
        Args:
            x: 输入张量
            mode: 'generator' 或 'discriminator'
            
        Returns:
            生成器或判别器的输出
        """
        if mode == 'generator':
            return self.generator(x)
        elif mode == 'discriminator':
            return self.discriminator(x)
        else:
            raise ValueError("Mode must be 'generator' or 'discriminator'")

# trainer.py
import torch

def train_gan(model, data_loader, criterion, optimizer, device='cpu', epochs=10):
    """
    训练GAN模型。
    
    Args:
        model (nn.Module): GAN模型
        data_loader (DataLoader): 训练数据加载器
        criterion: 损失函数（如 BCEWithLogitsLoss）
        optimizer: 优化器（通常需要为G和D分别定义，但这里假设传入的是一个字典）
        device (str): 训练设备 ('cpu' 或 'cuda')
        epochs (int): 训练轮数
        
    Returns:
        nn.Module: 训练好的模型
    """
    # TODO: run several iterations of the training loop(based on epochs parameter) and return the model
    model.to(device)
    model.train()  # 设置为训练模式
    
    # 分离生成器和判别器的优化器
    # 假设传入的optimizer是一个字典，包含'generator'和'discriminator'两个键
    if isinstance(optimizer, dict):
        optimizer_G = optimizer['generator']
        optimizer_D = optimizer['discriminator']
    else:
        # 如果只传入一个优化器，则使用同一个（不推荐，但为了兼容性）
        optimizer_G = optimizer_D = optimizer
    
    for epoch in range(epochs):
        for i, (real_images, _) in enumerate(data_loader):
            batch_size = real_images.size(0)
            real_images = real_images.to(device)
            
            # 创建标签
            real_labels = torch.ones(batch_size, 1).to(device)  # 真实图像标签为1
            fake_labels = torch.zeros(batch_size, 1).to(device)  # 伪造图像标签为0
            
            # ----------------------------
            # 训练判别器 D
            # ----------------------------
            optimizer_D.zero_grad()
            
            # 用真实图像训练D
            outputs = model(real_images, mode='discriminator')
            d_loss_real = criterion(outputs, real_labels)
            d_loss_real.backward()
            
            # 用伪造图像训练D
            noise = torch.randn(batch_size, 100).to(device)  # 生成随机噪声
            fake_images = model(noise, mode='generator')      # 生成假图像
            outputs = model(fake_images.detach(), mode='discriminator')  # detach避免梯度流向G
            d_loss_fake = criterion(outputs, fake_labels)
            d_loss_fake.backward()
            
            # 合并损失并更新D
            d_loss = d_loss_real + d_loss_fake
            optimizer_D.step()
            
            # ----------------------------
            # 训练生成器 G
            # ----------------------------
            optimizer_G.zero_grad()
            
            # 生成假图像，并让D判断它们为真
            noise = torch.randn(batch_size, 100).to(device)
            fake_images = model(noise, mode='generator')
            outputs = model(fake_images, mode='discriminator')  # 注意：这里不detach
            g_loss = criterion(outputs, real_labels)  # 目标是让G骗过D
            g_loss.backward()
            optimizer_G.step()
            
            # 可选：打印训练信息
            if (i+1) % 100 == 0:
                print(f"Epoch [{epoch+1}/{epochs}], Step [{i+1}/{len(data_loader)}], "
                      f"D Loss: {d_loss.item():.4f}, G Loss: {g_loss.item():.4f}")
    
    return model  # 返回训练好的模型

# generator.py
import torch
import matplotlib.pyplot as plt
import numpy as np

def generate_samples(model, device, num_samples=10):
    """
    使用训练好的GAN生成手写数字样本。
    
    Args:
        model (nn.Module): 训练好的GAN模型
        device (str): 设备 ('cpu' 或 'cuda')
        num_samples (int): 要生成的样本数量
    """
    # TODO: generate num_samples points in the latent space, run the generator to construct the image, and plot the samples on a grid plt.show()
    model.eval()  # 设置为评估模式
    with torch.no_grad():  # 关闭梯度计算
        # 生成潜在空间中的随机噪声
        noise = torch.randn(num_samples, 100).to(device)
        
        # 通过生成器生成图像
        generated_images = model(noise, mode='generator')
        generated_images = generated_images.cpu()  # 移动到CPU以便绘图
        
        # 将Tensor转换为numpy数组
        images_np = generated_images.squeeze().numpy()  # 移除通道维度 (1, 28, 28) -> (28, 28)
        
        # 计算网格大小
        cols = int(np.ceil(np.sqrt(num_samples)))
        rows = int(np.ceil(num_samples / cols))
        
        # 创建子图并绘制图像
        fig, axes = plt.subplots(rows, cols, figsize=(cols*2, rows*2))
        axes = axes.flatten() if num_samples > 1 else [axes]
        
        for idx, ax in enumerate(axes):
            if idx < num_samples:
                ax.imshow(images_np[idx], cmap='gray')
                ax.axis('off')
            else:
                ax.axis('off')  # 如果网格有空余，隐藏坐标轴
        
        plt.tight_layout()
        plt.show()