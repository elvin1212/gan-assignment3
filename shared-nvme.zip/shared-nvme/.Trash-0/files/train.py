import torch
from torch.utils.data import DataLoader
from torchvision import datasets, transforms
from torchvision.utils import make_grid
import matplotlib.pyplot as plt
import os

# 从你的模块导入
from helper_lib.model import get_model
from helper_lib.trainer import train_gan
from helper_lib.generator import generate_samples

# ----------------------------
# 实验目录管理
# ----------------------------
runs_dir = "runs"
os.makedirs(runs_dir, exist_ok=True)

existing_experiments = [d for d in os.listdir(runs_dir) if d.startswith("exp_")]
if existing_experiments:
    exp_numbers = [int(d.split("_")[1]) for d in existing_experiments if d.split("_")[1].isdigit()]
    next_exp_num = max(exp_numbers) + 1 if exp_numbers else 1
else:
    next_exp_num = 1

exp_name = f"exp_{next_exp_num:03d}"
exp_dir = os.path.join(runs_dir, exp_name)
os.makedirs(exp_dir, exist_ok=True)

images_dir = os.path.join(exp_dir, "images")
os.makedirs(images_dir, exist_ok=True)

samples_dir = os.path.join(images_dir, "epoch_samples")
os.makedirs(samples_dir, exist_ok=True)

# ----------------------------
# 数据预处理与加载
# ----------------------------
transform = transforms.Compose([
    transforms.ToTensor(),
    transforms.Normalize((0.5,), (0.5,))  # 输出范围 [-1, 1]，配合 Tanh
])

dataset = datasets.MNIST(root='./data', train=True, download=True, transform=transform)
dataloader = DataLoader(dataset, batch_size=64, shuffle=True, num_workers=30) 

# ----------------------------
# 模型、损失、优化器
# ----------------------------
device = 'cuda' if torch.cuda.is_available() else 'cpu'
model = get_model("GAN").to(device)

criterion = torch.nn.BCEWithLogitsLoss()

optimizer_G = torch.optim.Adam(model.generator.parameters(), lr=2e-4, betas=(0.5, 0.999))
optimizer_D = torch.optim.Adam(model.discriminator.parameters(), lr=2e-4, betas=(0.5, 0.999))
optimizer = {'generator': optimizer_G, 'discriminator': optimizer_D}

# ----------------------------
#在训练过程中记录损失
# ----------------------------
loss_history = {'discriminator': [], 'generator': []}

print(f"Starting training experiment: {exp_name}")
model.train()

for epoch in range(100):
    d_loss_total = 0.0
    g_loss_total = 0.0
    num_batches = 0

    for real_images, _ in dataloader:
        batch_size = real_images.size(0)
        real_images = real_images.to(device)

        real_labels = torch.ones(batch_size, 1, device=device)
        fake_labels = torch.zeros(batch_size, 1, device=device)

        # ----------------------------
        # 训练判别器
        # ----------------------------
        optimizer['discriminator'].zero_grad()

        # 真实图像
        outputs = model(real_images, mode='discriminator')
        d_loss_real = criterion(outputs, real_labels)

        # 生成假图像
        noise = torch.randn(batch_size, 100, device=device)
        fake_images = model(noise, mode='generator').detach()
        outputs = model(fake_images, mode='discriminator')
        d_loss_fake = criterion(outputs, fake_labels)

        d_loss = d_loss_real + d_loss_fake
        d_loss.backward()
        optimizer['discriminator'].step()

        # ----------------------------
        # 训练生成器
        # ----------------------------
        optimizer['generator'].zero_grad()
        noise = torch.randn(batch_size, 100, device=device)
        fake_images = model(noise, mode='generator')
        outputs = model(fake_images, mode='discriminator')
        g_loss = criterion(outputs, real_labels)
        g_loss.backward()
        optimizer['generator'].step()

        d_loss_total += d_loss.item()
        g_loss_total += g_loss.item()
        num_batches += 1

    # 记录平均损失
    avg_d_loss = d_loss_total / num_batches
    avg_g_loss = g_loss_total / num_batches
    loss_history['discriminator'].append(avg_d_loss)
    loss_history['generator'].append(avg_g_loss)

    print(f"Epoch [{epoch+1}/100] Avg Loss - D: {avg_d_loss:.4f}, G: {avg_g_loss:.4f}")

    # 每 10 个 epoch 保存一次生成样本
    if (epoch + 1) % 10 == 0:
        model.eval()
        with torch.no_grad():
            noise = torch.randn(16, 100, device=device)
            fake_images = model(noise, mode='generator').cpu()
            grid = make_grid(fake_images, nrow=4, padding=2, normalize=True)
            plt.figure(figsize=(5, 5))
            plt.imshow(grid.permute(1, 2, 0).squeeze(), cmap='gray')
            plt.axis('off')
            plt.title(f'Generated Samples - Epoch {epoch+1}')
            sample_path = os.path.join(samples_dir, f"epoch_{epoch+1:03d}.png")
            plt.savefig(sample_path, bbox_inches='tight')
            plt.close()
        model.train()

# ----------------------------
# 保存最终模型
# ----------------------------
model_save_path = os.path.join(exp_dir, "gan_model.pth")
torch.save(model.state_dict(), model_save_path)
print(f"Trained model saved to {model_save_path}")

# ----------------------------
# 绘制并保存损失曲线
# ----------------------------
plt.figure(figsize=(10, 5))
plt.plot(loss_history['discriminator'], label='Discriminator Loss')
plt.plot(loss_history['generator'], label='Generator Loss')
plt.xlabel('Epoch')
plt.ylabel('Loss')
plt.title('Training Loss over Epochs')
plt.legend()
plt.grid(True)
loss_plot_path = os.path.join(images_dir, 'loss_curve.png')
plt.savefig(loss_plot_path)
plt.show()
print(f"Loss curve saved to {loss_plot_path}")

# ----------------------------
# 保存损失日志
# ----------------------------
loss_log_path = os.path.join(exp_dir, 'loss_log.txt')
with open(loss_log_path, 'w') as f:
    f.write("Epoch\tD_Loss\tG_Loss\n")
    for epoch, (d_loss, g_loss) in enumerate(zip(loss_history['discriminator'], loss_history['generator']), 1):
        f.write(f"{epoch}\t{d_loss:.6f}\t{g_loss:.6f}\n")
print(f"Detailed loss history saved to {loss_log_path}")

# ----------------------------
# 最终生成样本（使用简化函数）
# ----------------------------
# 注意：generate_samples 不支持 save_path，所以先显示再保存
def generate_and_save(model, device, num_samples=16, save_path=None):
    model.eval()
    with torch.no_grad():
        noise = torch.randn(num_samples, 100, device=device)
        fake_images = model(noise, mode='generator').cpu()
        grid = make_grid(fake_images, nrow=4, padding=2, normalize=True)
        plt.figure(figsize=(5, 5))
        plt.imshow(grid.permute(1, 2, 0).squeeze(), cmap='gray')
        plt.axis('off')
        if save_path:
            plt.savefig(save_path, bbox_inches='tight')
            plt.close()
        else:
            plt.show()

final_sample_path = os.path.join(images_dir, 'final_samples.png')
generate_and_save(model, device, num_samples=16, save_path=final_sample_path)
print(f"Final generated samples saved to {final_sample_path}")

print(f"Training completed. All results are saved in: {exp_dir}")