import torch
import torch.nn as nn
import torch.optim as optim
import torchvision
import torchvision.transforms as transforms
from torch.utils.data import DataLoader
from torchvision.datasets import MNIST
import matplotlib.pyplot as plt
import numpy as np

# 设置随机种子以确保可重复性
torch.manual_seed(42)

# 设置设备
device = torch.device('mps' if torch.backends.mps.is_available() else ('cuda' if torch.cuda.is_available() else 'cpu'))

# 生成器网络
# 生成器的作用是将随机噪声转换为逼真的图像
# 网络结构采用转置卷积的方式，逐步将低维噪声向量升维到图像大小
class Generator(nn.Module):
    def __init__(self, latent_dim):
        super(Generator, self).__init__()
        self.latent_dim = latent_dim  # 潜在空间维度，用于控制生成图像的多样性
        
        self.main = nn.Sequential(
            # 第一层：将潜在向量映射到高维特征空间
            # 输入shape: (batch_size, latent_dim)
            # 输出shape: (batch_size, 256*7*7)
            nn.Linear(latent_dim, 256 * 7 * 7),
            nn.BatchNorm1d(256 * 7 * 7),  # 批归一化有助于训练稳定性
            nn.ReLU(True),  # 使用ReLU激活函数引入非线性
            
            # 重塑为卷积层的输入格式
            # 输入shape: (batch_size, 256*7*7)
            # 输出shape: (batch_size, 256, 7, 7)
            nn.Flatten(0, -1),
            nn.Unflatten(0, (-1, 256, 7, 7)),
            
            # 第一个转置卷积层
            # 输入shape: (batch_size, 256, 7, 7)
            # 输出shape: (batch_size, 128, 14, 14)
            nn.ConvTranspose2d(256, 128, kernel_size=4, stride=2, padding=1),
            nn.BatchNorm2d(128),
            nn.ReLU(True),
            
            # 第二个转置卷积层
            # 输入shape: (batch_size, 128, 14, 14)
            # 输出shape: (batch_size, 64, 28, 28)
            nn.ConvTranspose2d(128, 64, kernel_size=4, stride=2, padding=1),
            nn.BatchNorm2d(64),
            nn.ReLU(True),
            
            # 最后的卷积层
            # 输入shape: (batch_size, 64, 28, 28)
            # 输出shape: (batch_size, 1, 28, 28)
            nn.Conv2d(64, 1, kernel_size=3, stride=1, padding=1),
            nn.Tanh()
        )
    
    def forward(self, z):
        return self.main(z)

# 判别器网络
# 判别器的作用是区分真实图像和生成器生成的假图像
# 网络结构使用卷积层逐步提取图像特征，最终输出二分类概率
class Discriminator(nn.Module):
    def __init__(self):
        super(Discriminator, self).__init__()
        
        self.main = nn.Sequential(
            # 第一层卷积：提取基础图像特征
            # 输入shape: (batch_size, 1, 28, 28) (MNIST图像尺寸)
            # 输出shape: (batch_size, 64, 14, 14)
            nn.Conv2d(1, 64, kernel_size=4, stride=2, padding=1),
            nn.LeakyReLU(0.2, inplace=True),  # LeakyReLU避免梯度消失
            nn.Dropout2d(0.3),  # Dropout防止过拟合
            
            # 第二层卷积
            # 输入shape: (batch_size, 64, 14, 14)
            # 输出shape: (batch_size, 128, 7, 7)
            nn.Conv2d(64, 128, kernel_size=4, stride=2, padding=1),
            nn.BatchNorm2d(128),
            nn.LeakyReLU(0.2, inplace=True),
            nn.Dropout2d(0.3),
            
            # 展平层
            # 输入shape: (batch_size, 128, 7, 7)
            # 输出shape: (batch_size, 128 * 7 * 7)
            nn.Flatten(),
            
            # 全连接层
            # 输入shape: (batch_size, 128 * 7 * 7)
            # 输出shape: (batch_size, 1)
            nn.Linear(128 * 7 * 7, 1),
            nn.Sigmoid()
        )
    
    def forward(self, x):
        return self.main(x)

# 超参数设置
# 这些参数的选择对GAN的训练稳定性和生成效果有重要影响
latent_dim = 100  # 潜在空间维度，较大的维度有助于生成更多样的图像
batch_size = 64   # 批次大小，平衡训练效率和内存占用
num_epochs = 100  # 训练轮数
lr = 0.0002      # 学习率，GAN训练需要较小的学习率以保持稳定
beta1 = 0.5      # Adam优化器的beta1参数，较小的值有助于训练稳定

# 数据加载和预处理
transform = transforms.Compose([
    transforms.ToTensor(),
    transforms.Normalize((0.5,), (0.5,))
])

dataset = MNIST(root='./data', train=True, download=True, transform=transform)
dataloader = DataLoader(dataset, batch_size=batch_size, shuffle=True)

# 初始化网络
generator = Generator(latent_dim).to(device)
discriminator = Discriminator().to(device)

# 损失函数和优化器
criterion = nn.BCELoss()
g_optimizer = optim.Adam(generator.parameters(), lr=lr, betas=(beta1, 0.999))
d_optimizer = optim.Adam(discriminator.parameters(), lr=lr, betas=(beta1, 0.999))

# 训练函数
# GAN的训练过程是一个动态博弈过程，需要平衡生成器和判别器的训练
def train():
    for epoch in range(num_epochs):
        for i, (real_images, _) in enumerate(dataloader):
            batch_size = real_images.size(0)
            real_images = real_images.to(device)
            
            # 训练判别器
            # 判别器需要学会区分真实图像（标签为1）和生成图像（标签为0）
            d_optimizer.zero_grad()  # 清空判别器的梯度
            label_real = torch.ones(batch_size, 1).to(device)    # 真实图像的标签为1
            label_fake = torch.zeros(batch_size, 1).to(device)   # 生成图像的标签为0
            
            # 计算判别器对真实图像的损失
            output_real = discriminator(real_images)  # 判别器对真实图像的预测结果
            d_loss_real = criterion(output_real, label_real)  # 计算真实图像的二元交叉熵损失

            # 生成假图像并计算判别器的损失
            noise = torch.randn(batch_size, latent_dim).to(device)  # 生成随机噪声
            fake_images = generator(noise)  # 使用生成器生成假图像
            output_fake = discriminator(fake_images.detach())  # detach()防止梯度传递到生成器
            d_loss_fake = criterion(output_fake, label_fake)  # 计算假图像的二元交叉熵损失

            # 计算判别器的总损失并更新参数
            d_loss = d_loss_real + d_loss_fake  # 判别器总损失是真假图像损失之和
            d_loss.backward()  # 反向传播计算梯度
            d_optimizer.step()  # 更新判别器参数
            
            # 训练生成器
            # 生成器的目标是生成能够欺骗判别器的图像
            g_optimizer.zero_grad()  # 清空生成器的梯度
            output_fake = discriminator(fake_images)  # 判别器对生成图像的预测
            # 生成器的损失：希望判别器将生成的图像判断为真实图像
            g_loss = criterion(output_fake, label_real)  # 使用真实标签计算损失

            g_loss.backward()  # 反向传播计算梯度
            g_optimizer.step()  # 更新生成器参数
            
            if i % 1000 == 0:
                print(f'Epoch [{epoch}/{num_epochs}] Batch [{i}/{len(dataloader)}] '
                      f'd_loss: {d_loss.item():.4f} g_loss: {g_loss.item():.4f}')
        
        # 每个epoch保存生成的图像样本
        if (epoch + 1) % 10 == 0:
            save_fake_images(epoch + 1)

# 保存生成的图像
def save_fake_images(epoch):
    # 保存生成器在当前epoch生成的图像样本
    generator.eval()  # 将生成器设置为评估模式
    with torch.no_grad():  # 不计算梯度，节省内存
        noise = torch.randn(16, latent_dim).to(device)  # 生成16个随机噪声向量
        fake_images = generator(noise)  # 生成16张图像
        fake_images = fake_images.cpu().numpy()  # 将张量转换为NumPy数组
        
        plt.figure(figsize=(4, 4))
        for i in range(16):
            plt.subplot(4, 4, i + 1)
            plt.imshow(fake_images[i, 0], cmap='gray')
            plt.axis('off')
        
        plt.savefig(f'fake_images_epoch_{epoch}.png')
        plt.close()
    generator.train()

if __name__ == '__main__':
    train()
